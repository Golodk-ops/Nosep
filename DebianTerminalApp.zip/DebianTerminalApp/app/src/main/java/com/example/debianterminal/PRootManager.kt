package com.example.debianterminal

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/**
 * Lanza y gestiona una sesión de bash dentro del rootfs de Debian usando proot,
 * montando /dev, /proc y /sys del sistema Android dentro del contenedor.
 *
 * NOTA SOBRE EL BINARIO PROOT:
 * Desde Android 10 (API 29), el sistema aplica una política W^X que impide
 * ejecutar binarios que la propia app haya descargado y marcado como
 * ejecutables en su almacenamiento privado (filesDir/cacheDir). Por eso el
 * binario estático de proot NO se descarga en tiempo de ejecución: se
 * distribuye dentro del propio APK como librería nativa
 * (app/src/main/jniLibs/<abi>/libproot.so, un binario ELF renombrado).
 * Android lo extrae automáticamente a un directorio con permisos de
 * ejecución (nativeLibraryDir) durante la instalación de la app, siempre que
 * "packaging.jniLibs.useLegacyPackaging = true" esté configurado en
 * build.gradle.kts. Este es el mismo mecanismo que usan Termux y apps
 * similares para ejecutar proot en Android moderno.
 */
class PRootManager(private val context: Context) {

    private val rootfsDir = File(context.filesDir, "debian")
    private val prootBinary = File(context.applicationInfo.nativeLibraryDir, "libproot.so")

    private var process: Process? = null
    private var writer: OutputStreamWriter? = null

    private val _outputFlow = MutableSharedFlow<String>(extraBufferCapacity = 512)
    val outputFlow = _outputFlow.asSharedFlow()

    /**
     * Arranca la sesión de bash y va emitiendo la salida en tiempo real por
     * [outputFlow]. Esta función se queda "colgada" leyendo hasta que el
     * proceso termina, así que debe lanzarse en una corrutina propia
     * (Dispatchers.IO).
     */
    suspend fun start() = withContext(Dispatchers.IO) {
        if (!prootBinary.exists()) {
            _outputFlow.emit(
                "Error: no se encontró el binario de proot en ${prootBinary.absolutePath}\n" +
                    "Asegúrate de incluir libproot.so en app/src/main/jniLibs/<abi>/\n"
            )
            return@withContext
        }

        val pb = ProcessBuilder(buildProotCommand())
        pb.redirectErrorStream(true)
        pb.directory(rootfsDir)
        pb.environment().apply {
            put("PROOT_TMP_DIR", context.cacheDir.absolutePath)
            put("LD_LIBRARY_PATH", context.applicationInfo.nativeLibraryDir)
            put("HOME", "/root")
            put("TERM", "xterm-256color")
        }

        try {
            process = pb.start()
            writer = OutputStreamWriter(process!!.outputStream)

            val reader = BufferedReader(InputStreamReader(process!!.inputStream))
            val buffer = CharArray(4096)
            while (true) {
                val read = reader.read(buffer)
                if (read == -1) break
                _outputFlow.emit(String(buffer, 0, read))
            }

            val exitCode = process?.waitFor() ?: -1
            _outputFlow.emit("\n[Sesión finalizada, código $exitCode]\n")
        } catch (e: Exception) {
            _outputFlow.emit("\nError ejecutando proot: ${e.message}\n")
        }
    }

    /**
     * Construye la línea de comando de proot:
     *  -r  ruta raíz del sistema Debian
     *  -b  bind-mount de directorios del sistema Android dentro del contenedor
     *  -w  directorio de trabajo inicial dentro del contenedor
     *  -0  simula ser el usuario root dentro del contenedor (fake root)
     */
    private fun buildProotCommand(): List<String> {
        val tmpDir = File(rootfsDir, "tmp").apply { mkdirs() }

        return listOf(
            prootBinary.absolutePath,
            "--link2symlink",
            "--kill-on-exit",
            "-0",
            "-r", rootfsDir.absolutePath,
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys",
            "-b", "${tmpDir.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root",
            "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "--login"
        )
    }

    /** Envía una línea de comando (como si el usuario la escribiera y pulsara Enter). */
    fun write(command: String) {
        writer?.let {
            it.write("$command\n")
            it.flush()
        }
    }

    /** Envía una secuencia cruda de caracteres/escape sin salto de línea añadido. */
    fun sendRawKey(rawSequence: String) {
        writer?.let {
            it.write(rawSequence)
            it.flush()
        }
    }

    /** Envía un carácter de control calculado a partir de una tecla (p.ej. CTRL+C). */
    fun sendControlChar(letter: Char) {
        val code = (letter.uppercaseChar().code and 0x1f)
        writer?.let {
            it.write(code)
            it.flush()
        }
    }

    fun stop() {
        try {
            writer?.close()
            process?.destroy()
        } catch (_: Exception) {
            // proceso ya finalizado
        }
    }
}
