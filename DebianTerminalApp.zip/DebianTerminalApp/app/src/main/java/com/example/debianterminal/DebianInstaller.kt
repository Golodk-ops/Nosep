package com.example.debianterminal

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import java.util.concurrent.TimeUnit

/**
 * Se encarga de comprobar si Debian 12 (Bookworm) ya está instalado en el
 * almacenamiento privado de la app y, si no lo está, descargar y extraer
 * el rootfs minimalista correspondiente a la arquitectura de la CPU.
 *
 * El rootfs se descarga desde las releases públicas del proyecto
 * termux/proot-distro (https://github.com/termux/proot-distro/releases),
 * que publica tarballs oficiales de Debian bookworm listos para proot.
 *
 * IMPORTANTE: verifica cuál es la última etiqueta de versión publicada en
 * ese repositorio y actualiza PROOT_DISTRO_VERSION en consecuencia, ya que
 * las rutas de descarga cambian con cada release.
 */
class DebianInstaller(private val context: Context) {

    companion object {
        private const val PROOT_DISTRO_VERSION = "v4.31.0"
        private const val GITHUB_RELEASE_BASE =
            "https://github.com/termux/proot-distro/releases/download/$PROOT_DISTRO_VERSION"
    }

    private val debianDir = File(context.filesDir, "debian")
    private val markerFile = File(context.filesDir, ".debian_installed")

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // descargas largas
        .build()

    /** true si el rootfs ya fue instalado y verificado previamente. */
    fun isInstalled(): Boolean = markerFile.exists() && File(debianDir, "bin/bash").exists()

    /**
     * Ejecuta el proceso completo de instalación. Reporta progreso mediante
     * [onProgress] (etapa descriptiva, porcentaje 0-100).
     */
    suspend fun install(onProgress: (stage: String, percent: Int) -> Unit) = withContext(Dispatchers.IO) {
        debianDir.mkdirs()

        val tarFile = File(context.cacheDir, "debian-rootfs.tar.xz")
        try {
            onProgress("Descargando Debian 12 (Bookworm)...", 0)
            downloadFile(resolveRootfsUrl(), tarFile) { percent ->
                onProgress("Descargando Debian 12 (Bookworm)...", percent)
            }

            onProgress("Extrayendo sistema de archivos...", 0)
            extractTarXz(tarFile, debianDir) { percent ->
                onProgress("Extrayendo sistema de archivos...", percent)
            }

            onProgress("Configurando red y DNS...", 90)
            writeResolvConf()
            ensureBaseDirectories()

            markerFile.writeText("ok")
            onProgress("Instalación completa", 100)
        } finally {
            tarFile.delete()
        }
    }

    private fun resolveRootfsUrl(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        val arch = when (abi) {
            "arm64-v8a" -> "aarch64"
            "armeabi-v7a" -> "arm"
            "x86_64" -> "x86_64"
            "x86" -> "i686"
            else -> "aarch64"
        }
        return "$GITHUB_RELEASE_BASE/debian-bookworm-$arch-pd-$PROOT_DISTRO_VERSION.tar.xz"
    }

    private fun downloadFile(url: String, destination: File, onProgress: (Int) -> Unit) {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Descarga fallida: HTTP ${response.code} ($url)")
            }
            val body = response.body ?: throw IOException("Respuesta vacía del servidor")
            val totalBytes = body.contentLength()
            var readBytes = 0L

            body.byteStream().use { input ->
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        readBytes += bytesRead
                        if (totalBytes > 0) {
                            onProgress(((readBytes * 100) / totalBytes).toInt().coerceIn(0, 100))
                        }
                    }
                }
            }
        }
    }

    /**
     * Extrae un tar.xz preservando permisos de ejecución y enlaces simbólicos,
     * imprescindible para que binarios como /bin/bash o /usr/bin/apt funcionen
     * correctamente dentro del contenedor proot.
     */
    private fun extractTarXz(tarXzFile: File, outputDir: File, onProgress: (Int) -> Unit) {
        val totalSize = tarXzFile.length().coerceAtLeast(1)
        var processedCompressedBytes = 0L

        BufferedInputStream(tarXzFile.inputStream()).use { fileStream ->
            val countingStream = CountingInputStream(fileStream) { processedCompressedBytes = it }
            XZCompressorInputStream(countingStream).use { xzStream ->
                TarArchiveInputStream(xzStream).use { tarStream ->
                    var entry: TarArchiveEntry? = tarStream.nextTarEntry
                    while (entry != null) {
                        val safeName = entry.name.removePrefix("./")
                        val outFile = File(outputDir, safeName)

                        when {
                            entry.isDirectory -> outFile.mkdirs()

                            entry.isSymbolicLink -> {
                                outFile.parentFile?.mkdirs()
                                try {
                                    if (Files.exists(outFile.toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS)) {
                                        outFile.delete()
                                    }
                                    Files.createSymbolicLink(outFile.toPath(), Paths.get(entry.linkName))
                                } catch (_: Exception) {
                                    // Symlinks inválidos o ya existentes: se ignoran de forma segura
                                }
                            }

                            else -> {
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { out -> tarStream.copyTo(out) }
                                applyPermissions(outFile, entry.mode)
                            }
                        }

                        // Progreso aproximado en base a bytes comprimidos leídos
                        onProgress(((processedCompressedBytes * 100) / totalSize).toInt().coerceIn(0, 100))
                        entry = tarStream.nextTarEntry
                    }
                }
            }
        }
    }

    private fun applyPermissions(file: File, mode: Int) {
        try {
            val ownerExec = (mode and 0b001_000_000) != 0
            val ownerWrite = (mode and 0b010_000_000) != 0
            file.setExecutable(ownerExec, false)
            file.setWritable(ownerWrite, false)
            file.setReadable(true, false)
        } catch (_: Exception) {
            // En algunos sistemas de archivos no se pueden aplicar todos los bits
        }
    }

    private fun ensureBaseDirectories() {
        listOf("dev", "proc", "sys", "tmp", "root").forEach {
            File(debianDir, it).mkdirs()
        }
    }

    private fun writeResolvConf() {
        val resolvConf = File(debianDir, "etc/resolv.conf")
        resolvConf.parentFile?.mkdirs()
        resolvConf.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
    }
}

/** InputStream auxiliar que reporta cuántos bytes de origen se han consumido. */
private class CountingInputStream(
    private val delegate: java.io.InputStream,
    private val onBytesRead: (Long) -> Unit
) : java.io.InputStream() {
    private var total = 0L
    override fun read(): Int {
        val b = delegate.read()
        if (b != -1) { total++; onBytesRead(total) }
        return b
    }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = delegate.read(b, off, len)
        if (n != -1) { total += n; onBytesRead(total) }
        return n
    }
    override fun close() = delegate.close()
}
