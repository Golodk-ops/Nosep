package com.example.debianterminal

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.debianterminal.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var installer: DebianInstaller
    private var prootManager: PRootManager? = null

    private var ctrlArmed = false
    private var altArmed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        installer = DebianInstaller(applicationContext)

        setupInputBar()
        setupQuickKeys()
        checkAndStartDebian()
    }

    // ---------------------------------------------------------------------
    // Instalación en el primer inicio
    // ---------------------------------------------------------------------

    private fun checkAndStartDebian() {
        lifecycleScope.launch {
            if (installer.isInstalled()) {
                startPRootSession()
                return@launch
            }

            showInstallOverlay(true)
            try {
                installer.install { stage, percent ->
                    runOnUiThread { updateInstallProgress(stage, percent) }
                }
                showInstallOverlay(false)
                appendOutput("Debian 12 (Bookworm) instalado correctamente.\n")
                startPRootSession()
            } catch (e: Exception) {
                showInstallOverlay(false)
                appendOutput("✗ Error durante la instalación: ${e.message}\n")
            }
        }
    }

    private fun showInstallOverlay(show: Boolean) {
        binding.installOverlay.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun updateInstallProgress(stage: String, percent: Int) {
        binding.installStatusText.text = "$stage ($percent%)"
        binding.installProgressBar.progress = percent
    }

    // ---------------------------------------------------------------------
    // Sesión de PRoot
    // ---------------------------------------------------------------------

    private fun startPRootSession() {
        val manager = PRootManager(applicationContext)
        prootManager = manager

        lifecycleScope.launch {
            manager.outputFlow.collect { chunk -> appendOutput(chunk) }
        }

        lifecycleScope.launch(Dispatchers.IO) {
            manager.start()
        }
    }

    // ---------------------------------------------------------------------
    // Entrada de comandos
    // ---------------------------------------------------------------------

    private fun setupInputBar() {
        binding.sendButton.setOnClickListener { sendCurrentCommand() }

        binding.commandInput.setOnEditorActionListener { _, actionId, event ->
            val isSend = actionId == EditorInfo.IME_ACTION_SEND
            val isEnterDown = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (isSend || isEnterDown) {
                sendCurrentCommand()
                true
            } else {
                false
            }
        }

        // Intercepta el siguiente carácter escrito cuando CTRL o ALT están "armados"
        binding.commandInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if ((ctrlArmed || altArmed) && !s.isNullOrEmpty()) {
                    val typedChar = s.last()
                    s.delete(s.length - 1, s.length)

                    if (ctrlArmed) {
                        prootManager?.sendControlChar(typedChar)
                        appendOutput("^${typedChar.uppercaseChar()}")
                        setCtrlArmed(false)
                    } else if (altArmed) {
                        prootManager?.sendRawKey("\u001B$typedChar")
                        setAltArmed(false)
                    }
                }
            }
        })
    }

    private fun sendCurrentCommand() {
        val command = binding.commandInput.text?.toString().orEmpty()
        if (command.isBlank()) return

        prootManager?.write(command)
        binding.commandInput.text?.clear()
    }

    // ---------------------------------------------------------------------
    // Teclas rápidas (ESC, TAB, CTRL, ALT, flechas)
    // ---------------------------------------------------------------------

    private fun setupQuickKeys() {
        binding.keyEsc.setOnClickListener { prootManager?.sendRawKey("\u001B") }
        binding.keyTab.setOnClickListener { prootManager?.sendRawKey("\t") }
        binding.keyUp.setOnClickListener { prootManager?.sendRawKey("\u001B[A") }
        binding.keyDown.setOnClickListener { prootManager?.sendRawKey("\u001B[B") }

        binding.keyCtrl.setOnClickListener { setCtrlArmed(!ctrlArmed) }
        binding.keyAlt.setOnClickListener { setAltArmed(!altArmed) }
    }

    private fun setCtrlArmed(armed: Boolean) {
        ctrlArmed = armed
        binding.keyCtrl.isSelected = armed
        binding.keyCtrl.alpha = if (armed) 1f else 0.6f
    }

    private fun setAltArmed(armed: Boolean) {
        altArmed = armed
        binding.keyAlt.isSelected = armed
        binding.keyAlt.alpha = if (armed) 1f else 0.6f
    }

    // ---------------------------------------------------------------------
    // Salida de la terminal
    // ---------------------------------------------------------------------

    private fun appendOutput(text: String) {
        binding.terminalOutput.append(text)
        binding.terminalScrollView.post {
            binding.terminalScrollView.fullScroll(android.view.View.FOCUS_DOWN)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        prootManager?.stop()
    }
}
