plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.debianterminal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.debianterminal"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        viewBinding = true
    }

    // IMPORTANTE:
    // Ejecutamos proot como proceso externo (ProcessBuilder), no vía JNI.
    // Para que el sistema extraiga libproot.so a nativeLibraryDir con permisos
    // de ejecución reales (y así evitar el bloqueo W^X de Android 10+),
    // necesitamos empaquetado "legacy" de las librerías nativas.
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // Corrutinas para IO en segundo plano y streaming de salida en tiempo real
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Descarga del rootfs con progreso
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Extracción de tar.xz preservando permisos y symlinks
    implementation("org.apache.commons:commons-compress:1.26.2")
    implementation("org.tukaani:xz:1.9")
}
