# Debian Terminal (Android + PRoot)

App de terminal Android que instala y ejecuta Debian 12 (Bookworm) mediante
PRoot, sin necesidad de root.

## Estructura

```
app/src/main/java/com/example/debianterminal/
  MainActivity.kt      -> UI de terminal, orquesta instalación + sesión
  DebianInstaller.kt   -> descarga y extrae el rootfs en el primer inicio
  PRootManager.kt       -> lanza bash dentro de Debian vía proot
app/src/main/res/layout/activity_main.xml -> UI (salida, teclas, input)
app/build.gradle.kts   -> dependencias
```

## ⚠️ Dos puntos críticos para que funcione en un dispositivo real

### 1. El binario de `proot` NO se descarga en tiempo de ejecución

Desde Android 10 (API 29), el sistema aplica una política W^X que **bloquea
la ejecución de cualquier binario que la app haya escrito y marcado como
ejecutable en su propio almacenamiento** (`filesDir`, `cacheDir`, etc.),
aunque le pongas `chmod +x`. Por eso este proyecto NO intenta descargar
`proot` por HTTP: eso funcionaría en emuladores viejos pero fallará (o será
rechazado por Play Store) en dispositivos modernos.

La solución que usan Termux y apps equivalentes (AnLinux, UserLAnd, etc.) es
distribuir el binario estático de proot **dentro del propio APK como si
fuera una librería nativa**, para que sea el propio instalador de Android
quien lo extraiga con permisos de ejecución:

1. Consigue un binario estático de `proot` para cada ABI que quieras
   soportar (por ejemplo, compilado desde
   https://github.com/termux/termux-packages, paquete `proot`, o extraído
   de un `.deb` de Termux).
2. Renómbralo a `libproot.so` (el nombre es arbitrario pero **debe empezar
   por `lib` y terminar en `.so`** para que el empaquetador de Android lo
   trate como librería nativa).
3. Colócalo en:
   ```
   app/src/main/jniLibs/arm64-v8a/libproot.so
   app/src/main/jniLibs/armeabi-v7a/libproot.so
   ```
   (se han dejado ya las carpetas vacías en este proyecto).
4. Asegúrate de que `build.gradle.kts` tiene:
   ```kotlin
   packaging { jniLibs { useLegacyPackaging = true } }
   ```
   (ya incluido en este proyecto) y que el manifiesto tiene
   `android:extractNativeLibs="true"` (ya incluido).

Con esto, en tiempo de ejecución el binario estará disponible y con permiso
de ejecución en `context.applicationInfo.nativeLibraryDir`, que es
exactamente lo que usa `PRootManager.kt`.

### 2. URL del rootfs de Debian

`DebianInstaller.kt` descarga el tarball desde las *releases* públicas del
proyecto `termux/proot-distro`:

```
https://github.com/termux/proot-distro/releases/download/<VERSION>/debian-bookworm-<arch>-pd-<VERSION>.tar.xz
```

La constante `PROOT_DISTRO_VERSION` debe actualizarse periódicamente
consultando https://github.com/termux/proot-distro/releases para apuntar a
la última etiqueta publicada (las URLs de versiones antiguas dejan de
existir). Si prefieres una fuente propia, aloja tú mismo el tarball (p. ej.
generado con `debootstrap`) y cambia `resolveRootfsUrl()`.

## Flujo de la app

1. `MainActivity` comprueba `DebianInstaller.isInstalled()`.
2. Si no existe, muestra el overlay de progreso y llama a
   `DebianInstaller.install()` en una corrutina de `Dispatchers.IO`, que:
   - descarga el `.tar.xz` con progreso vía OkHttp,
   - lo extrae con `commons-compress` preservando permisos y symlinks,
   - escribe `/etc/resolv.conf` para que `apt` tenga DNS funcional.
3. Al terminar (o si ya estaba instalado), `PRootManager.start()` lanza:
   ```
   proot -0 -r <rootfs> -b /dev -b /proc -b /sys -w /root \
         /usr/bin/env -i HOME=/root TERM=xterm-256color PATH=... \
         /bin/bash --login
   ```
4. Todo lo que el usuario escribe en el `EditText` se envía por `stdin` del
   proceso; la salida de `stdout`/`stderr` se emite en tiempo real por un
   `SharedFlow` y se pinta en el `TextView` de la terminal.
5. Los botones ESC/TAB/▲/▼ envían secuencias de escape ANSI directamente;
   CTRL/ALT "arman" el siguiente carácter que se escriba para convertirlo en
   `Ctrl+<letra>` o `Alt+<letra>`.

## Comandos ya soportados de fábrica

Al ser una sesión de `bash --login` real dentro de un rootfs de Debian
completo, `apt update`, `apt install`, `uname -a`, `whoami`, etc. funcionan
igual que en cualquier Debian, sujeto a las limitaciones propias de proot
(sin acceso real a red a bajo nivel más allá de lo que el kernel de Android
permita, sin montaje de sistemas de archivos reales, etc.).
